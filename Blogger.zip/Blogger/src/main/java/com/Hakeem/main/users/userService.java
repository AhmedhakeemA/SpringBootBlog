package com.Hakeem.main.users;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Hakeem.main.posts.post;



@Service
public class userService {

	@Autowired
	userRepository repository;

	
	
	public List<user> getallUsers() {

		List<user> topicsz =new ArrayList<>();
		repository.findAll().forEach(topicsz::add);
		return topicsz;
	}
	
	public Optional<user> getUser(String id) {
		
		//return topics.get(Integer.valueOf(id));
		return	repository.findById(id);

	}
}
