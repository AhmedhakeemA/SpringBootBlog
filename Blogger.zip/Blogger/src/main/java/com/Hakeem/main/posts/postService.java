package com.Hakeem.main.posts;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class postService {

	@Autowired
	private postRepository repository;
	
//	private List<topic> topics =new ArrayList<>(
//			Arrays.asList(
//			new topic( "Spring", "Spring", "this is Spring framwork"),
//			new topic("Java", "Java", "Core Java Describtion"),
//			new topic("JavaScript", "JavaScript", "Decribtion of JavaScript")
//			));

	public List<post> getallTopics() {

		List<post> topicsz =new ArrayList<>();
		repository.findAll().forEach(topicsz::add);
		return topicsz;
	}
	
	public Optional<post> getTopic(String id) {
		
		//return topics.get(Integer.valueOf(id));
		return	repository.findById(id);

	}

	public void addTopic(post topic) {

		repository.save(topic);
		
		
	}

	public void UpdateTopic(post topic, String id) {
			repository.save(topic);
				return;

		
	}


	public void deleteTopic(String id) {
		repository.deleteById(id);
		return;
	}
}
