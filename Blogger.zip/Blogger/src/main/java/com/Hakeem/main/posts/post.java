package com.Hakeem.main.posts;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.Hakeem.main.users.user;

@Entity
public class post {

	@Id
	private String  id;
	private String body;
	private String title;

	
	@ManyToOne

	private user user;
	
	public user getUser() {
		return user;
	}

	public void setUser(user user) {
		this.user = user;
	}

	
	
	public post() {}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}


	public post(String id, String body, String title, String userid) {
		super();
		this.id = id;
		this.body = body;
		this.title = title;
		this.user = new user(userid, "", "","");
	}
	
		

}
