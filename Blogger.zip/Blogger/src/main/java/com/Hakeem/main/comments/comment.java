package com.Hakeem.main.comments;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.Hakeem.main.posts.post;

@Entity
public class comment {

	@Id
	private int  id;
	private String name;
	private String Describtion;
	
	@ManyToOne
	private post post;
	
	public post getTopic() {
		return post;
	}

	public void setTopic(post post) {
		this.post = post;
	}

	public comment() {}
	
	public comment(int id, String name, String describtion,String post_id) {
		super();
		this.id = id;
		this.name = name;
		Describtion = describtion;
		this.post = new post(post_id, "", "","");
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getDescribtion() {
		return Describtion;
	}




	

}
