package com.Hakeem.main.users;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.Hakeem.main.posts.post;

@RestController
public class UserController {

	@Autowired
	userService  service;

	@RequestMapping(method=RequestMethod.GET,value="/user")
	public List<user> GetAllposts() {
		
		return service.getallUsers();
	}
	
	@RequestMapping("/user/{id}")
	public Optional<user> getTopic(@PathVariable("id") String id) {
		
		return service.getUser(id);
	}
	
	
	
}
