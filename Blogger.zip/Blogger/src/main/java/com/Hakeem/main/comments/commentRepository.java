package com.Hakeem.main.comments;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

public interface commentRepository extends CrudRepository<comment, String> {

	public List<comment> findByName(String name);
//	public List<Course> findByDescribtion(String name);
	public List<comment> findByPostId(String topicId);
	

	
		

}
