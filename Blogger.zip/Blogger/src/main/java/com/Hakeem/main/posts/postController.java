package com.Hakeem.main.posts;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class postController {
	
	@Autowired
	private postService toppicservice;
	
	@RequestMapping(method=RequestMethod.GET,value="/posts")
	public List<post> GetAllposts() {
		
		return toppicservice.getallTopics();
	}
	
	@RequestMapping("/posts/{id}")
	public Optional<post> getTopic(@PathVariable("id") String id) {
		
		return toppicservice.getTopic(id);
	}
	@RequestMapping(method=RequestMethod.POST,value="/posts")
	public void addTopic(@RequestBody post topic) {
		toppicservice.addTopic(topic);
	}
	
	@RequestMapping(method=RequestMethod.PUT,value="/posts/{id}")
	public void UpdateTopic(@RequestBody post topic,@PathVariable("id") String id) {
		toppicservice.UpdateTopic(topic,id);
	}
	
	@RequestMapping(method=RequestMethod.DELETE,value="/posts/{id}")
	public String deleteTopic(@PathVariable("id") String id) {
		toppicservice.deleteTopic(id);
		return "sucess delete id "+id;
	}
	
	

}
