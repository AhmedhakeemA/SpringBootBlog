package com.Hakeem.main.comments;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class commentService {

	@Autowired
	private commentRepository courseRepository;
	
//	private List<topic> topics =new ArrayList<>(
//			Arrays.asList(
//			new topic( "Spring", "Spring", "this is Spring framwork"),
//			new topic("Java", "Java", "Core Java Describtion"),
//			new topic("JavaScript", "JavaScript", "Decribtion of JavaScript")
//			));

	public List<comment> getallCourses(String topicId) {

		List<comment> courses =new ArrayList<>();
		courseRepository.findByPostId(topicId)
		.forEach(courses::add);
		
		for (comment comment : courses) {
			System.out.println(comment);
		}
		
		return courses;
	}
	
	public Optional<comment> getCourse(String id) {
		

		return	courseRepository.findById(id);

	}

	public void addCourse(comment course) {

		courseRepository.save(course);
		
		
	}

	public void UpdateCourse(comment course) {
		courseRepository.save(course);
				return;

		
	}


	public void deleteCourse(String id) {
		courseRepository.deleteById(id);
		return;
	}
}
