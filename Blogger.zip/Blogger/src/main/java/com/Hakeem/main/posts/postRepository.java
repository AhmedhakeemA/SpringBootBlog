package com.Hakeem.main.posts;

import org.springframework.data.repository.CrudRepository;

public interface postRepository extends CrudRepository<post, String> {

}
