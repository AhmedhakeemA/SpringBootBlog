package com.Hakeem.main.comments;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.Hakeem.main.posts.post;

@RestController
public class commentController {
	
	@Autowired
	private commentService courseservice;
	
	@RequestMapping("/posts/{id}/courses")
	public List<comment> GetAllCourses(@PathVariable("id") String id) {
		
		return courseservice.getallCourses(id);
	}
	
	@RequestMapping("/posts/{topicid}/courses/{id}")
	public Optional<comment> getcourse(@PathVariable("id") String id) {
		
		return courseservice.getCourse(id);
	}
	@RequestMapping(method=RequestMethod.POST,value="/posts/{topicId}/courses")
	public void addCourse(@RequestBody comment course,@PathVariable("topicId") String topicId) {
		course.setTopic(new post(topicId, "", "",""));
		courseservice.addCourse(course);
	}
	
	@RequestMapping(method=RequestMethod.PUT,value="/posts/{topicId}/courses/{id}")
	public void Updatecourse(@RequestBody comment course,@PathVariable("id") String id) {
		courseservice.UpdateCourse(course);
	}
	
	@RequestMapping(method=RequestMethod.DELETE,value="/posts/{topicId}/courses/{id}")
	public String deletecourse(@PathVariable("id") String id) {
		courseservice.deleteCourse(id);
		return "sucess delete id "+id;
	}
	
	

}
